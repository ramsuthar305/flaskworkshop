import os

class config:
    DEBUG = True
    FLASK_ENV='development'